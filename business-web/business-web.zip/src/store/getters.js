const getters = {
    loading: state => state.loading,
    isPC: state => state.isPC,
}
export default getters
